function About() {
  return (
    <div>
      <h1>foadSES</h1>
      <p>PAO COM MOFADO</p>
    </div>
  );
}

export default About;
